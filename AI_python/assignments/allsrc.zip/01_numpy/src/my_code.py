import numpy as np

a = np.zeros([3,4])

np.save("m1out.npy", a)